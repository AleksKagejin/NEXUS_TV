package tv.nexus.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(9, 15, 23)
    private val accent = Color.rgb(91, 211, 242)
    private lateinit var grid: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildUi()
    }

    private fun panel(color: Int, radius: Float): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(42, 28, 42, 24)
            background = GradientDrawable(GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(10, 20, 31), bg, Color.rgb(16, 31, 43)))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = TextView(this).apply {
            text = "N E X U S"
            textSize = 24f
            letterSpacing = .16f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        val date = TextView(this).apply {
            text = "  TV  •  SMART HOME"
            textSize = 11f
            setTextColor(0xff8fa8b8.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(brand)
        header.addView(date)
        root.addView(header, LinearLayout.LayoutParams(-1, 44))

        val clock = TextView(this).apply {
            text = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            textSize = 48f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setPadding(0, 18, 0, 0)
        }
        root.addView(clock)

        val subtitle = TextView(this).apply {
            text = "Ваше пространство развлечений"
            textSize = 14f
            setTextColor(0xff91a8b7.toInt())
            setPadding(0, 0, 0, 20)
        }
        root.addView(subtitle)

        grid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))
        val apps = loadApps()
        if (apps.isEmpty()) {
            val hint = TextView(this).apply { text = "Приложения не найдены"; setTextColor(Color.WHITE); textSize = 18f }
            grid.addView(hint)
        } else {
            apps.take(8).forEach { info ->
                val tile = TextView(this).apply {
                    text = info.loadLabel(packageManager).toString()
                    textSize = 15f
                    gravity = Gravity.CENTER
                    setTextColor(Color.WHITE)
                    setPadding(12, 16, 12, 16)
                    background = panel(0xff1b2b39.toInt(), 22f)
                    isFocusable = true
                    isFocusableInTouchMode = true
                    setOnFocusChangeListener { v, focused ->
                        v.animate().scaleX(if (focused) 1.055f else 1f)
                            .scaleY(if (focused) 1.055f else 1f).setDuration(120).start()
                        v.background = panel(if (focused) 0xff24495b.toInt() else 0xff1b2b39.toInt(), 22f)
                        if (focused) v.elevation = 10f else v.elevation = 0f
                    }
                    setOnClickListener {
                        val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                        if (launch != null) startActivity(launch)
                    }
                }
                val lp = LinearLayout.LayoutParams(0, 118, 1f)
                lp.setMargins(6, 8, 6, 8)
                grid.addView(tile, lp)
            }
            if (grid.childCount > 0) grid.getChildAt(0).requestFocus()
        }

        val footer = TextView(this).apply {
            text = "NEXUS TV     •     ЛЁГКИЙ ИНТЕРФЕЙС"
            textSize = 10f
            letterSpacing = .12f
            setTextColor(0xff718b9b.toInt())
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(footer, LinearLayout.LayoutParams(-1, 28))
        setContentView(root)
    }

    private fun loadApps(): List<android.content.pm.ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val tv = packageManager.queryIntentActivities(intent, 0)
        val normal = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        return (tv + normal).distinctBy { it.activityInfo.packageName }
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }
}
