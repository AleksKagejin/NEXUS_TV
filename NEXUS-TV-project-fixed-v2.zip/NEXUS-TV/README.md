# NEXUS TV

Lightweight Android TV launcher prototype.

## Build
GitHub Actions workflow: Actions → Build NEXUS TV APK → Run workflow.
The generated APK is available under the completed run's Artifacts section.

This is an early prototype; test it alongside your existing launcher before setting it as the default.
